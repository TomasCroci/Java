
package ar.org.centro8.curso.java.repositories.interfaces;
import ar.org.centro8.curso.java.entities.Libro;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public interface I_LibroRepository {
    void save(Libro libro);
    void remove(Libro libro);
    void update(Libro libro);
    List <Libro> getAll();
    default Stream<Libro> getStream(){
        return getAll().stream();
    }
    default Libro getById(int id){
        return getStream().filter(l->l.getId()==id).findAny().orElse(new Libro());
    }
  default  List<Libro> getLikeTitulo(String titulo){
      if(titulo==null) return new ArrayList<Libro>();
      return getStream().filter(l->l.getTitulo().toLowerCase().contains(titulo.toLowerCase()))
              .collect(Collectors.toList());
  }
   default List<Libro> getLikeTituloAutor(String titulo, String autor){
       if(titulo==null || autor==null) return new ArrayList<Libro>();
        return getStream().filter(l->l.getTitulo().toLowerCase().contains(titulo.toLowerCase())
            && l.getAutor().toLowerCase().contains(autor.toLowerCase()) )
              .collect(Collectors.toList());
   }
   default List<Libro> getLikeAutor(String autor) {
       if(autor==null) return new ArrayList<Libro>();
       return getStream().filter(l->l.getTitulo().toLowerCase().contains(autor.toLowerCase()))
               .collect(Collectors.toList());
   }
   
   default List<Libro> getLikeEditorial(String editorial) {
       if(editorial==null) return new ArrayList<Libro>();
       return getStream().filter(l->l.getEditorial().toLowerCase().contains(editorial.toLowerCase()))
               .collect(Collectors.toList());
   }
   default List<Libro> getByAñoPublicacion (int añoPublicacion) {
       return getStream().filter(l->l.getAñoPublicacion()==añoPublicacion)
               .collect(Collectors.toList());
   }
}
