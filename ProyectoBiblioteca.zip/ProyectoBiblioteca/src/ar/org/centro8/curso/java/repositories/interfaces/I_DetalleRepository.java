
package ar.org.centro8.curso.java.repositories.interfaces;
import ar.org.centro8.curso.java.entities.Detalle;
import ar.org.centro8.curso.java.entities.Libro;
import ar.org.centro8.curso.java.enums.Tipo;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;
public interface I_DetalleRepository {
    void save(Detalle detalle);
    void remove(Detalle detalle);
    void update(Detalle detalle);
    List<Detalle> getAll();
    default Stream<Detalle> getStream(){
        return getAll().stream();
    }
    default Detalle getById(int id) {
        return getStream().filter(d->d.getId()==id).findAny().orElse(new Detalle());
    }
    default List<Detalle> getByLibro(Libro libro) {
        if(libro==null) return new ArrayList<Detalle>();
        return getStream().filter(e->e.getIdLibro()==libro.getId())
                .collect(Collectors.toList());
    }
    default List<Detalle> getByTipo(Tipo tipo) {
        if(tipo==null) return new ArrayList<Detalle>();
        return getStream().filter(e->e.getTipo()==tipo)
                .collect(Collectors.toList());
    }
}
