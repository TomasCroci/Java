
package ar.org.centro8.curso.java.repositories.interfaces;
import ar.org.centro8.curso.java.entities.Socio;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public interface I_SocioRepository {
    void save(Socio socio);
    void remove(Socio socio);
    void update(Socio socio);
    List<Socio>getAll();
    default Stream<Socio> getStream() {
        return getAll().stream();
    }
    default Socio getById(int id) {
        return getStream().filter(s->s.getId()==id).findAny().orElse(new Socio());
    }
    default List<Socio> getLikeNombre(String nombre) {
         if(nombre==null) return new ArrayList<Socio>();
         return getStream()
                 .filter(s->s.getNombre().toLowerCase().contains(nombre.toLowerCase()))
                 .collect(Collectors.toList());
    }
    default List<Socio> getLikeNombreApellido(String nombre, String apellido) {
         if(nombre==null || apellido==null) return new ArrayList<Socio>();
          return getStream()
                 .filter(s->s.getNombre().toLowerCase().contains(nombre.toLowerCase())
                  && s.getApellido().toLowerCase().contains(apellido.toLowerCase()) )
                  .collect(Collectors.toList());
    }
    default List<Socio> getLikeDireccion(String direccion) {
        if(direccion==null) return new ArrayList<Socio>();
         return getStream()
                 .filter(s->s.getDireccion().toLowerCase().contains(direccion.toLowerCase()))
                 .collect(Collectors.toList());
    }
    default List<Socio> getByDni(double dni) {
        return getStream()
                .filter(s->s.getDni()==dni)
               .collect(Collectors.toList());
    }
}
