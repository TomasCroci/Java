
package ar.org.centro8.curso.java.test;

import ar.org.centro8.curso.java.connectors.Connector;
import ar.org.centro8.curso.java.entities.Detalle;
import ar.org.centro8.curso.java.entities.Empleado;
import ar.org.centro8.curso.java.entities.Libro;
import ar.org.centro8.curso.java.entities.Local;
import ar.org.centro8.curso.java.entities.Socio;
import ar.org.centro8.curso.java.enums.Barrio;
import ar.org.centro8.curso.java.enums.Posicion;
import ar.org.centro8.curso.java.enums.Tipo;
import ar.org.centro8.curso.java.repositories.interfaces.I_DetalleRepository;
import ar.org.centro8.curso.java.repositories.interfaces.I_EmpleadoRepository;
import ar.org.centro8.curso.java.repositories.interfaces.I_LocalRepository;
import ar.org.centro8.curso.java.repositories.interfaces.I_SocioRepository;
import ar.org.centro8.curso.java.repositories.interfaces.I_LibroRepository;
import ar.org.centro8.curso.java.repositories.jdbc.DetalleRepository;
import ar.org.centro8.curso.java.repositories.jdbc.EmpleadoRepository;
import ar.org.centro8.curso.java.repositories.jdbc.LocalRepository;
import ar.org.centro8.curso.java.repositories.jdbc.SocioRepository;
import ar.org.centro8.curso.java.repositories.jdbc.LibroRepository;


public class TestRepositories {
    public static void main(String[] args) {
        
        System.out.println("*********Tabla Libros***************");
        I_LibroRepository lr=new LibroRepository(Connector.getConnection());
         lr.getAll().forEach(System.out::println);
         /*
         System.out.println("******Eliminar libro id=6*******");
         lr.remove(lr.getById(6));
         lr.getAll().forEach(System.out::println);
         */
         
         System.out.println("**********Agregar libro a id=15**********");
         Libro l1=new Libro(15,"El Principito","Saint-Exupèry","Emece",1970);
         lr.save(l1);
         
         System.out.println("************Mostrar libro id=10***************");
         System.out.println(lr.getById(10));
         
         System.out.println("**********Mostrar  autor like Lovecraft***********");
        lr.getLikeAutor("Lovecraft").forEach(System.out::println);
         
         System.out.println("***********Mostrar libro autor like El sepulcro, Lovecraft**********");
         lr.getLikeTituloAutor("El sepulcro", "Lovecraft").forEach(System.out::println);
         
         System.out.println("**********Mostrar editorial like El Ateneo************");
         lr.getLikeEditorial("El Ateneo").forEach(System.out::println);
         
         System.out.println("**********Mostrar libros con titulo like 'La'*********");
         lr.getLikeTitulo("La").forEach(System.out::println);
         
           System.out.println("******Tabla locales******");
         I_LocalRepository Lr=new LocalRepository(Connector.getConnection());
         Lr.getAll().forEach(System.out::println);
         
         System.out.println("*******Mostrar locales id=1********");
         System.out.println(Lr.getById(1));
         
         System.out.println("*****Mostrar locales where barrio= 'BOEDO'**********");
         Lr.getByBarrio(Barrio.BOEDO).forEach(System.out::println);
         
         
         
         System.out.println("***********Mostrar locales con direccion like 'Ma'");
         Lr.getLikeDireccion("Ma").forEach(System.out::println);
         
         
         System.out.println("**********Tabla Empleados*********");
         I_EmpleadoRepository er=new EmpleadoRepository(Connector.getConnection());
         er.getAll().forEach(System.out::println);
         
         System.out.println("********Mostrar empleado id=4*********");
         System.out.println(er.getById(4));
         
         System.out.println("******Mostrar empleados del local 3*******");
         er.getByLocal(Lr.getById(3)).forEach(System.out::println);
         
         System.out.println("*******Mostrar empleados con nombre 'Ma'");
         er.getLikeNombre("Ma").forEach(System.out::println);
         
         System.out.println("*********Mostrar empleados con nombre like 'Ma' y apellido like 'Pu'");
         er.getLikeNombreApellido("Ma", "Pu").forEach(System.out::println);
         
         System.out.println("********Mostrar empleados posicion 'BIBLIOTECARIO'");
         er.getByPosicion(Posicion.BIBLIOTECARIO).forEach(System.out::println);
       
         
         System.out.println("********Tabla Socios********");
         I_SocioRepository sr=new SocioRepository(Connector.getConnection());
         sr.getAll().forEach(System.out::println);
         
         System.out.println("******Mostrar socio nombre like 'Es'*********");
         sr.getLikeNombre("Es").forEach(System.out::println);
         
         System.out.println("******Agregar un socio por id=12*******");
         Socio s1=new Socio(12,"Ruben","Cuevas",00000000,"Avellaneda 1420");
         sr.save(s1);
         
         System.out.println("*********Tabla Detalles**********");
         I_DetalleRepository dr=new DetalleRepository(Connector.getConnection());
         dr.getAll().forEach(System.out::println);
         
         System.out.println("******Tabla actualizada*******");
         dr.getAll().forEach(System.out::println);
         
         /*
         System.out.println("*********Eliminar libro id=6*********");
         dr.remove(dr.getByLibro(6));
         */
         System.out.println("**********Agregar libro id=15*******");
         Detalle d1=new Detalle(15,Tipo.LITERARIO);
         dr.save(d1);
         
         System.out.println("*******Mostrar detalle por IdLibro=7*****");
         dr.getByLibro(lr.getById(7)).forEach(System.out::println);
         
         System.out.println("******Mostrar detalles 'LITERARIOS'*******");
         dr.getByTipo(Tipo.LITERARIO).forEach(System.out::println);
         
        System.out.println("******Tabla actualizada*******");
         dr.getAll().forEach(System.out::println);
   
        
        
    }
}
