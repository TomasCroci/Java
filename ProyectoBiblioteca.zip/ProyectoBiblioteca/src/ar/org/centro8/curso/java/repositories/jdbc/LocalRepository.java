
package ar.org.centro8.curso.java.repositories.jdbc;

import ar.org.centro8.curso.java.entities.Local;
import ar.org.centro8.curso.java.enums.Barrio;
import ar.org.centro8.curso.java.repositories.interfaces.I_LocalRepository;
import java.util.List;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;


public class LocalRepository implements I_LocalRepository {
    private Connection conn;

    public LocalRepository(Connection conn) {
        this.conn = conn;
    }
    
    

    @Override
    public void save(Local local) {
        if(local==null) return;
        try(PreparedStatement ps=conn.prepareStatement("insert into locales (direccion,cantidadEmpleados,barrio",
                PreparedStatement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, local.getDireccion());
            ps.setInt(2, local.getCantidadEmpleados());
            ps.setString(3, local.getBarrio().toString());
            ps.execute();
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void remove(Local local) {
        if(local==null) return;
        try(PreparedStatement ps=conn.prepareStatement("delete from locales where id=?")) {
            ps.setInt(1, local.getId());
            ps.execute();
            
        } catch (Exception e) {
            e.printStackTrace();
        }
   }

    @Override
    public void update(Local local) {
        if(local==null) return;
        try(PreparedStatement ps=conn.prepareStatement("update locales set direccion=?,cantidadEmpleados=?,barrio=?,where id=?")) {
            ps.setString(1, local.getDireccion());
            ps.setInt(2, local.getCantidadEmpleados());
            ps.setString(3, local.getBarrio().toString());
            ps.execute();
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public List<Local> getAll() {
        List<Local>list=new ArrayList();
        try(ResultSet rs=conn.createStatement().executeQuery("select * from locales")) {
            while(rs.next()) {
                list.add(new Local(
                rs.getString("direccion"),
                rs.getInt("cantidadEmpleados"),
                Barrio.valueOf(rs.getString("barrio"))
                ));
            }
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
    
}
