drop database if exists biblioteca;
create database biblioteca;
use biblioteca;
drop table if exists libros;
drop table if exists empleados;
drop table if exists locales;
drop table if exists socios;
drop table if exists detalles;


create table libros(
id int auto_increment primary key,
titulo varchar(150) not null,
autor varchar(45) not null,
editorial varchar(20) not null,
añoPublicacion int not null
);

create table empleados(
id int auto_increment primary key,
idLocal int,
nombre varchar(20),
apellido varchar(20) not null,
edad int,
posicion enum('BIBLIOTECARIO','AYUDANTE')
);

create table locales(
id int auto_increment primary key,
direccion varchar(150),
cantidadEmpleados int,
barrio enum('CABALLITO', 'PALERMO', 'FLORES', 'BOEDO')
);

create table socios(
id int auto_increment primary key,
nombre varchar(20),
apellido varchar(20),
dni double,
direccion varchar(150)
);

create table detalles(
id int auto_increment primary key,
idLibro int,
tipo enum('LITERARIO', 'NOLITERARIO')
);

alter table detalles
add constraint FK_Detalles_idLibro
foreign key (idLibro)
references libros(id);

alter table empleados
add constraint FK_Empleados_idLocal
foreign key (idLocal)
references locales(id);