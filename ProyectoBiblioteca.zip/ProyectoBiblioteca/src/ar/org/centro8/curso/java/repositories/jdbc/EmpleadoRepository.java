
package ar.org.centro8.curso.java.repositories.jdbc;
import ar.org.centro8.curso.java.entities.Empleado;
import ar.org.centro8.curso.java.enums.Posicion;
import ar.org.centro8.curso.java.repositories.interfaces.I_EmpleadoRepository;

import java.util.List;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class EmpleadoRepository implements I_EmpleadoRepository{
    private Connection conn;

    public EmpleadoRepository(Connection conn) {
        this.conn = conn;
    }

    @Override
    public void save(Empleado empleado) {
        if(empleado==null) return;
        try(PreparedStatement ps=conn.prepareStatement(
                "insert into empleados(idLocal,nombre,apellido,edad,posicion) values(?,?,?,?,?)",
                PreparedStatement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, empleado.getIdLocal());
            ps.setString(2, empleado.getNombre());
            ps.setString(3, empleado.getApellido());
            ps.setInt(4, empleado.getEdad());
            ps.setString(5, empleado.getPosicion().toString());
            ps.execute();
              ResultSet rs=ps.getGeneratedKeys();
             if(rs.next()) empleado.setId(rs.getInt(1));
            {
                   
                }
            
        } catch (Exception e) {
            e.printStackTrace();
        }
  }

    @Override
    public void remove(Empleado empleado) {
        if(empleado==null) return;
        try(PreparedStatement ps=conn.prepareStatement("delete from empleados where id=?")) {
            ps.setInt(1, empleado.getId());
            ps.execute();
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void update(Empleado empleado) {
        if(empleado==null) return;
        try(PreparedStatement ps=conn.prepareStatement("update empleados set idLocal=?,nombre=?,apellido=?,edad=?,posicion=?, where id=?")) {
              ps.setInt(1, empleado.getIdLocal());
            ps.setString(2, empleado.getNombre());
            ps.setString(3, empleado.getApellido());
            ps.setInt(4, empleado.getEdad());
            ps.setString(5, empleado.getPosicion().toString());
            ps.setInt(6, empleado.getId());
            ps.execute();
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        
   }

    @Override
    public List<Empleado> getAll() {
        List<Empleado>list=new ArrayList();
        try(ResultSet rs=conn.createStatement().executeQuery("select * from empleados")) {
            while(rs.next()){
                list.add(new Empleado(
                rs.getInt("id"),
                rs.getInt("idLocal"),
                rs.getString("nombre"),
                rs.getString("apellido"),
                rs.getInt("edad"),
                Posicion.valueOf(rs.getString("posicion"))
                        ));
            }
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
   }
    
    
}
