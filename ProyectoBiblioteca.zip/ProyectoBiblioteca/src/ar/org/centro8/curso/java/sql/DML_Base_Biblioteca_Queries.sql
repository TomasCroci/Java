--use biblioteca;

--Mostrar toda la tabla detalle incluyendo nombre y autor de cada libro.
select d.idLibro, d.tipo, l.nombre, l.autor from detalles d join libros l on l.id=d.idLibro;

--Mostrar todos los libros literarios de la tabla detalles
select * from detalles where tipo= 'LITERARIO';

--Mostrar todos los libros no literarios publicados antes de 1983
select d.idLibro, d.tipo, l.añoPublicacion from detalles d join libros l on l.id=d.idLibro;
select * from detalles where tipo= 'NOLITERARIO' and añoPublicacion<1983;