--use biblioteca;

--Mostrar todos los empleados del local 1, incluyendo direccion y barrio
select e.idLocal, e.nombre, e.apellido, e.edad, e.posicion, l.direccion, l.barrio
from empleados e join locales l on l.id=e.idLocal
where l.id=1;


--Mostrar todos los libros literarios de la tabla detalles
select * from detalles where tipo= 'LITERARIO';

--Mostrar todos los libros  publicados antes de 1983
select * from libros where añoPublicacion<1983;