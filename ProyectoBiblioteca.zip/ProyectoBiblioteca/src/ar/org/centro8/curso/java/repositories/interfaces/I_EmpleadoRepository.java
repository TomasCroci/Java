
package ar.org.centro8.curso.java.repositories.interfaces;
import ar.org.centro8.curso.java.entities.Empleado;
import ar.org.centro8.curso.java.entities.Local;
import ar.org.centro8.curso.java.enums.Posicion;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public interface I_EmpleadoRepository {
    void save(Empleado empleado);
    void remove (Empleado empleado);
    void update (Empleado empleado);
    List<Empleado> getAll();
    default Stream<Empleado> getStream(){
        return getAll().stream();
    }
    default Empleado getById(int id) {
        return getStream().filter(e->e.getId()==id).findAny().orElse(new Empleado());
    }
    default List<Empleado> getLikeApellido(String apellido) {
         if(apellido==null) return new ArrayList<Empleado>();
        return getStream()
                .filter(e->e.getApellido().toLowerCase().contains(apellido.toLowerCase()))
                .collect(Collectors.toList());
    }
    default List<Empleado> getLikeNombre(String nombre){
        if(nombre==null) return new ArrayList<Empleado>();
        return getStream().filter(e->e.getNombre().toLowerCase().contains(nombre.toLowerCase()))
                .collect(Collectors.toList());
    }
    default List<Empleado> getLikeNombreApellido(String nombre, String apellido) {
        if(nombre==null || apellido==null) return new ArrayList<Empleado>();
        return getStream().filter(e->e.getNombre().toLowerCase().contains(nombre.toLowerCase())
         && e.getApellido().toLowerCase().contains(apellido.toLowerCase()) )
                .collect(Collectors.toList());
    }
    default List<Empleado> getByLocal(Local local) {
        if(local==null) return new ArrayList<Empleado>();
        return getStream()
                .filter(e->e.getIdLocal()==local.getId())
                .collect(Collectors.toList());
    }
     default List<Empleado> getByPosicion (Posicion posicion) {
        if(posicion==null) return new ArrayList<Empleado>();
        return getStream()
                .filter(e->e.getPosicion()==posicion)
                .collect(Collectors.toList());
    }
}
