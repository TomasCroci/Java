
package ar.org.centro8.curso.java.enums;


public enum Barrio {
    CABALLITO,
    PALERMO,
    FLORES,
    BOEDO
}
