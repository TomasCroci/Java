
package ar.org.centro8.curso.java.repositories.jdbc;

import ar.org.centro8.curso.java.entities.Socio;
import ar.org.centro8.curso.java.repositories.interfaces.I_SocioRepository;
import java.util.List;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;


public class SocioRepository implements I_SocioRepository{
   private Connection conn;

    public SocioRepository(Connection conn) {
        this.conn = conn;
    }
   
   

    @Override
    public void save(Socio socio) {
        if(socio==null) return;
        try(PreparedStatement ps=conn.prepareStatement("insert into socios (nombre,apellido,dni,direccion) values (?,?,?,?)",
        PreparedStatement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, socio.getNombre());
            ps.setString(2, socio.getApellido());
            ps.setDouble(3, socio.getDni());
            ps.setString(4, socio.getDireccion());
            ps.execute();
              ResultSet rs=ps.getGeneratedKeys();
             if(rs.next()) socio.setId(rs.getInt(1));
            
            
        } catch (Exception e) {
            e.printStackTrace();
        }
   } 

    @Override
    public void remove(Socio socio) {
        if(socio==null) return;
        try(PreparedStatement ps=conn.prepareStatement("delete from socios where id=?")) {
            ps.setInt(1, socio.getId());
            ps.execute();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void update(Socio socio) {
        if(socio==null) return;
        try(PreparedStatement ps=conn.prepareStatement("update set nombre=?,apellido=?,dni=?,direccion=?, where id=?")) {
           ps.setString(1, socio.getNombre());
            ps.setString(2, socio.getApellido());
            ps.setDouble(3, socio.getDni());
            ps.setString(4, socio.getDireccion());
            ps.setInt(5, socio.getId());
            ps.execute();
      
        } catch (Exception e) {
            e.printStackTrace();
        }
   }

    @Override
    public List<Socio> getAll() {
        List<Socio>list=new ArrayList();
         try(ResultSet rs=conn.createStatement().executeQuery("select * from socios")) {
            while(rs.next()){
                list.add(new Socio(
                rs.getInt("id"),
                rs.getString("nombre"),
                rs.getString("apellido"),
                rs.getInt("edad"),
                rs.getString("direccion")
              
                     ));
            }
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
   }
    
}
