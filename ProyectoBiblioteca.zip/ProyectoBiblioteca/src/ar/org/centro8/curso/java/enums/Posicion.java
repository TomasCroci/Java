
package ar.org.centro8.curso.java.enums;


public enum Posicion {
    BIBLIOTECARIO,
    AYUDANTE
}
