
package ar.org.centro8.curso.java.entities;

import ar.org.centro8.curso.java.enums.Tipo;


public class Detalle {
    private int id;
    private int idLibro;
    private Tipo tipo;

    public Detalle() {
    }

    public Detalle(int idLibro, Tipo tipo) {
        this.idLibro = idLibro;
        this.tipo = tipo;
    }

    public Detalle(int id, int idLibro, Tipo tipo) {
        this.id = id;
        this.idLibro = idLibro;
        this.tipo = tipo;
    }

    @Override
    public String toString() {
        return "Detalle{" + "id=" + id + ", idLibro=" + idLibro + ", tipo=" + tipo + '}';
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getIdLibro() {
        return idLibro;
    }

    public void setIdLibro(int idLibro) {
        this.idLibro = idLibro;
    }

    public Tipo getTipo() {
        return tipo;
    }

    public void setTipo(Tipo tipo) {
        this.tipo = tipo;
    }
    
    
}
