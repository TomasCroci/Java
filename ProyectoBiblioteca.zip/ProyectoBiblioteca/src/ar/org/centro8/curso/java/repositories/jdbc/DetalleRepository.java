
package ar.org.centro8.curso.java.repositories.jdbc;

import ar.org.centro8.curso.java.entities.Detalle;
import ar.org.centro8.curso.java.enums.Tipo;
import ar.org.centro8.curso.java.repositories.interfaces.I_DetalleRepository;
import java.util.List;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;



public class DetalleRepository implements I_DetalleRepository {
    public Connection conn;

    public DetalleRepository(Connection conn) {
        this.conn = conn;
    }
    
    

    @Override
    public void save(Detalle detalle) {
        if(detalle==null) return;
        try(PreparedStatement ps=conn.prepareStatement("insert into detalles (idLibro,tipo) values (?,?)",
                PreparedStatement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, detalle.getIdLibro());
            ps.setString(2, detalle.getTipo().toString());
            ps.execute();
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        }

    @Override
    public void remove(Detalle detalle) {
        if(detalle==null) return;
        try(PreparedStatement ps=conn.prepareStatement("delete from detalles where id=?")) {
            ps.setInt(1, detalle.getId());
            ps.execute();
            
        } catch (Exception e) {
            e.printStackTrace();
        }
  }

    @Override
    public void update(Detalle detalle) {
        if(detalle==null) return;
        try(PreparedStatement ps=conn.prepareStatement("update detalles set idLibro=?,tipo=?,where id=?")) {
             ps.setInt(1, detalle.getIdLibro());
            ps.setString(2, detalle.getTipo().toString());
            ps.setInt(3, detalle.getId());
            ps.execute();
            
        } catch (Exception e) {
            e.printStackTrace();
        }
   }

    @Override
    public List<Detalle> getAll() {
        List<Detalle>list=new ArrayList();
        try(ResultSet rs=conn.createStatement().executeQuery("select * from detalles")) {
            while(rs.next()){
                list.add(new Detalle(
                rs.getInt("id"),
                rs.getInt("idLibro"),
                        Tipo.valueOf(rs.getString("tipo"))        
                ));
            }
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
       }
    
}
