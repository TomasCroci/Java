--use biblioteca;

insert into libros (titulo,autor,editorial,añoPublicacion) values
('El horror de Dunwich','Lovecraft','Alianza',1980),
('En la cripta','Lovecraft','Alianza',1983),
('Dagón y otros cuentos macabros','Lovecraft','Alianza',1984),
('En las montañas de la locura y otros relatos','Lovecraft','Alianza',1981),
('El alquimista','Lovecraft','Lucar',1974),
('El sepulcro','Lovecraft','Lucar',1974),
('La enseñanza del derecho y el ejercicio de la abogacía','Böhmer','Gedisa',1999),
('La formación del Imperio Romano','Grimal','Siglo XXI',1984),
('El siglo XX : Problemas mundiales entre los dos bloques de poder','Benz','Siglo XXI',1985),
('El gato negro y otros cuentos','Poe','Norma',1999),
('Los asesinatos de la Rue Morgue','Poe','Norma',1997),
('Programación y computación electrónica','Gregory','El Ateneo',1980),
('Metodos de computación','Naur','El Ateneo',1980),
('Temas de computación eléctronica','Benice','El Ateneo',1980);


insert into locales(direccion,barrio,cantidadEmpleados) values
('Avellaneda 542','CABALLITO',3),
('Av. San Pedrito 1026','FLORES',2),
('Guemes 4621','PALERMO',2),
('Maza 755','BOEDO',2);

insert into empleados (idLocal,nombre,apellido,edad,posicion) values
(1,'Mario','Puertas',29,'BIBLIOTECARIO'),
(1,'Marcelo','Gimenez',19,'AYUDANTE'),
(1,'Gonzalo','Flores',18,'AYUDANTE'),
(2,'Alejandra','Artaza',38,'BIBLIOTECARIO'),
(2,'Gabriel','Raffin',20,'AYUDANTE'),
(3,'Malena','Pacifico',18,'AYUDANTE'),
(3,'Martha','Roldan',40,'BIBLIOTECARIO'),
(4,'Juan','Cuevas',58,'BIBLIOTECARIO'),
(4,'Ivan','Berruto',19,'AYUDANTE');



insert into socios (nombre,apellido,dni,direccion) values
('Roberto','Paredes',00000000,'Maza 598'),
('Miguel','Gomez',00000000,'Maza 390'),
('Maria','Paredes',00000000,'Maza 598'),
('Gimena','Gomez',00000000,'Maza 390'),
('Gerardo','Lopez',00000000,'Avellaneda 980'),
('Esteban','Flores',00000000,'Avellaneda 1329'),
('Mariano','Croci',00000000,'Guemes 4268'),
('Esperanza','Flores',00000000,'Avellaneda 1329'),
('Guillermo','Torres',00000000,'Av. San Pedrito 1243'),
('Tomas','Berruto',00000000,'Guemes 4890'),
('Antonio','Torres',00000000,'Av. San Pedrito 1243');


insert into detalles (idLibro,tipo) values
(1,'LITERARIO'),
(2,'LITERARIO'),
(3,'LITERARIO'),
(4,'LITERARIO'),
(5,'LITERARIO'),
(6,'LITERARIO'),
(7,'NOLITERARIO'),
(8,'NOLITERARIO'),
(9,'NOLITERARIO'),
(10,'LITERARIO'),
(11,'LITERARIO'),
(12,'NOLITERARIO'),
(13,'NOLITERARIO'),
(14,'NOLITERARIO');