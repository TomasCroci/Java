
package ar.org.centro8.curso.java.repositories.jdbc;

import ar.org.centro8.curso.java.entities.Libro;
import ar.org.centro8.curso.java.repositories.interfaces.I_LibroRepository;
import java.util.List;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
public class LibroRepository implements I_LibroRepository{
    private Connection conn;

    public LibroRepository(Connection conn) {
        this.conn = conn;
    }
    

    @Override
    public void save(Libro libro) {
        if(libro==null) return;
        try(PreparedStatement ps=conn.prepareStatement(
                "insert into libros(titulo,autor,editorial,añoPublicacion) values(?,?,?,?)",
                PreparedStatement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, libro.getTitulo());
            ps.setString(2, libro.getAutor());
            ps.setString(3, libro.getEditorial());
            ps.setInt(4, libro.getAñoPublicacion());
            ps.execute();
            ResultSet rs=ps.getGeneratedKeys();
            if(rs.next()) libro.setId(rs.getInt(1));
        } catch (Exception e) {
            e.printStackTrace();
        }
       }

    @Override
    public void remove(Libro libro) {
        if(libro==null) return;
       try (PreparedStatement ps=conn.prepareStatement("delete from libros where id=?")){
                    ps.setInt(1, libro.getId());
                    ps.execute();
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void update(Libro libro) {
        if(libro==null) return;
        try(PreparedStatement ps=conn.prepareStatement("update libros set titulo=?,autor=?,editorial=?,añoPublicacion=?, where id=?")) {
            ps.setString(1, libro.getTitulo());
            ps.setString(2, libro.getAutor());
            ps.setString(3, libro.getEditorial());
            ps.setInt(4, libro.getAñoPublicacion());
            ps.setInt(5, libro.getId());
            ps.execute();
        } catch (Exception e) {
            e.printStackTrace();
        }
     }

    @Override
    public List<Libro> getAll() {
        List<Libro>list=new ArrayList();
        try(ResultSet rs=conn.createStatement().executeQuery("select * from libros")) {
            while(rs.next()){
                list.add(new Libro(
                rs.getInt("id"),
                rs.getString("titulo"),
                rs.getString("autor"),
                rs.getString("editorial"),
                rs.getInt("añoPublicacion")));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
   }
    
}
