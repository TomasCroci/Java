
package ar.org.centro8.curso.java.gui;
import ar.org.centro8.curso.java.connectors.Connector;
import ar.org.centro8.curso.java.entities.Empleado;
import ar.org.centro8.curso.java.entities.Local;
import ar.org.centro8.curso.java.enums.Barrio;
import ar.org.centro8.curso.java.enums.Posicion;
import ar.org.centro8.curso.java.repositories.interfaces.I_EmpleadoRepository;
import ar.org.centro8.curso.java.repositories.jdbc.EmpleadoRepository;
import ar.org.centro8.curso.java.repositories.interfaces.I_LocalRepository;
import ar.org.centro8.curso.java.repositories.jdbc.LocalRepository;
import ar.org.centro8.curso.java.utils.swing.Table;
import ar.org.centro8.curso.java.utils.swing.Validator;
import javax.swing.JOptionPane;


public class FormLocales extends javax.swing.JInternalFrame {
private I_EmpleadoRepository er = new EmpleadoRepository(Connector.getConnection());
private I_LocalRepository lr = new LocalRepository(Connector.getConnection());
    
    public FormLocales() {
         super(
                "Formulario de Locales",                         //title
                false,                     //resizable
                true,                      //closable
                  false,                   //maximizable
                  true                       //iconable
        );
        initComponents();
        
        cargarElemento();
        
    }
    
    private void cargarElemento() {
        // cargar cmb Barrio
       cmbBarrio.removeAllItems();
        for(Barrio b:Barrio.values()) cmbBarrio.addItem(b);
        
         new Table().cargar(tblLocal, lr.getAll());
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        txtDireccion = new javax.swing.JTextField();
        txtCantidadEmpleados = new javax.swing.JTextField();
        btnAgregar = new javax.swing.JButton();
        lblinfo = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblLocal = new javax.swing.JTable();
        jLabel4 = new javax.swing.JLabel();
        txtBuscarDireccion = new javax.swing.JTextField();
        btnEliminar = new javax.swing.JButton();
        btnMostrarEmpleados = new javax.swing.JButton();
        cmbBarrio = new javax.swing.JComboBox<>();

        jLabel1.setText("Direccion:");

        jLabel2.setText("Cantidad de Empleados:");

        jLabel3.setText("Barrio:");

        btnAgregar.setText("Agregar");
        btnAgregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAgregarActionPerformed(evt);
            }
        });

        lblinfo.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jScrollPane1.setViewportView(tblLocal);

        jLabel4.setText("Buscar Direccion:");

        txtBuscarDireccion.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtBuscarDireccionKeyReleased(evt);
            }
        });

        btnEliminar.setText("Eliminar");
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });

        btnMostrarEmpleados.setText("Mostrar Empleados");
        btnMostrarEmpleados.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMostrarEmpleadosActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel1)
                                    .addComponent(jLabel2)
                                    .addComponent(jLabel3))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 33, Short.MAX_VALUE)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtCantidadEmpleados, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtDireccion, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(cmbBarrio, javax.swing.GroupLayout.PREFERRED_SIZE, 183, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addComponent(lblinfo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel4)
                                .addGap(29, 29, 29)
                                .addComponent(txtBuscarDireccion, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(btnEliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(70, 70, 70)
                                .addComponent(btnAgregar, javax.swing.GroupLayout.PREFERRED_SIZE, 237, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(36, 36, 36)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(btnMostrarEmpleados, javax.swing.GroupLayout.PREFERRED_SIZE, 301, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 301, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(txtDireccion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(txtCantidadEmpleados, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(15, 15, 15)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(cmbBarrio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(13, 13, 13)
                .addComponent(lblinfo, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnAgregar, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 7, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(txtBuscarDireccion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnEliminar))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 205, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(5, 5, 5)
                .addComponent(btnMostrarEmpleados)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnAgregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAgregarActionPerformed
        // Evento Agregar
        if(!validar()) return;
        Local local= new Local(
        txtDireccion.getText(),
                Integer.parseInt(txtCantidadEmpleados.getText()),
                cmbBarrio.getItemAt(cmbBarrio.getSelectedIndex())
        );
        lr.save(local);
        lblinfo.setText("Se agrego el local id:"+local.getId());
        cargarElemento();
        
    }//GEN-LAST:event_btnAgregarActionPerformed

    private void txtBuscarDireccionKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtBuscarDireccionKeyReleased
        // Evento Buscar Barrio
        new Table().cargar(tblLocal, lr.getLikeDireccion(txtBuscarDireccion.getText()));
    }//GEN-LAST:event_txtBuscarDireccionKeyReleased

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
        // Evento Eliminar
        int fila=tblLocal.getSelectedRow();
        if(fila==-1) return;
        int id=(int)tblLocal.getValueAt(fila, 0);
        //System.out.println(id);
         if(JOptionPane.showConfirmDialog(this, "Desea borrar el local id:"+id+"?")!=0) return;
      Local local=lr.getById(id);
      if(er.getByLocal(local).size()!=0){
          JOptionPane.showMessageDialog(this, "El local no se puede eliminar, porque contiene empleados!","error",JOptionPane.ERROR_MESSAGE);
          return;
      }
   
     lr.remove(local);
        
    }//GEN-LAST:event_btnEliminarActionPerformed

    private void btnMostrarEmpleadosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMostrarEmpleadosActionPerformed
        // Mostrar Empleado
         // Evento Mostrar empleados
         int fila = tblLocal.getSelectedRow();
        if(fila==-1) return;
        int id=(int)tblLocal.getValueAt(fila, 0);
          Local local=lr.getById(id);
    
          ListarEmpleados le = new ListarEmpleados(local);
         (this.getParent()).add(le);
         le.setVisible(true);
    }//GEN-LAST:event_btnMostrarEmpleadosActionPerformed
private boolean validar(){
    if(!new Validator(txtDireccion).length(3, 20)) return false;
    return true;
}
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAgregar;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnMostrarEmpleados;
    private javax.swing.JComboBox<Barrio> cmbBarrio;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblinfo;
    private javax.swing.JTable tblLocal;
    private javax.swing.JTextField txtBuscarDireccion;
    private javax.swing.JTextField txtCantidadEmpleados;
    private javax.swing.JTextField txtDireccion;
    // End of variables declaration//GEN-END:variables
}
