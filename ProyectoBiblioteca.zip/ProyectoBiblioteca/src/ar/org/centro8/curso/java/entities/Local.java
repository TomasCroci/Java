
package ar.org.centro8.curso.java.entities;

import ar.org.centro8.curso.java.enums.Barrio;

public class Local {
    private int id;
    private String direccion;
    private int cantidadEmpleados;
    private Barrio barrio;

    public Local() {
    }

    public Local(String direccion, int cantidadEmpleados, Barrio barrio) {
        this.direccion = direccion;
        this.cantidadEmpleados = cantidadEmpleados;
        this.barrio = barrio;
    }

    public Local(int id, String direccion, int cantidadEmpleados, Barrio barrio) {
        this.id = id;
        this.direccion = direccion;
        this.cantidadEmpleados = cantidadEmpleados;
        this.barrio = barrio;
    }

    @Override
    public String toString() {
        return "Local{" + "id=" + id + ", direccion=" + direccion + ", cantidadEmpleados=" + cantidadEmpleados + ", barrio=" + barrio + '}';
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public int getCantidadEmpleados() {
        return cantidadEmpleados;
    }

    public void setCantidadEmpleados(int cantidadEmpleados) {
        this.cantidadEmpleados = cantidadEmpleados;
    }

    public Barrio getBarrio() {
        return barrio;
    }

    public void setBarrio(Barrio barrio) {
        this.barrio = barrio;
    }
    
    
}
